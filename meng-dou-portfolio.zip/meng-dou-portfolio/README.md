# Meng Dou — Portfolio

A personal portfolio site for **Meng Dou**, Senior Data Scientist & AI Product Owner at ASML, built to read clearly as a hybrid Data Scientist / Product Manager profile within the first few seconds of landing.

## Design concept

The site's signature motif is a **KPI health signal** — a thin animated waveform (`components/SignalLine.tsx`) that echoes the actual work described in the resume: monitoring equipment KPIs and flagging failure before it happens. It appears once, boldly, in the hero (with an "anomaly flagged, 12 days early" annotation), then recedes into a quiet divider used between sections — one bold idea, kept disciplined everywhere else.

- **Palette**: deep graphite background, teal signal accent (the "healthy" reading), amber accent reserved for flagged/validated states — inspired by an instrument readout rather than a generic gradient hero.
- **Type**: Space Grotesk (display) for structure and personality, Inter (body) for long-form readability, IBM Plex Mono for data labels, stats, status tags, and navigation — reinforcing the "telemetry" feel throughout.
- **Structure**: Case studies use dashboard-style status tags (`LIVE IN PRODUCTION`, `VALIDATED · GTM IN PROGRESS`, etc.) instead of generic numbered markers, since status is what's actually true about each project.
- **Dark / light mode**: toggle in the nav, persisted to `localStorage`, defaults to dark.

## Content notes

All copy was rewritten from the source résumé into achievement-driven language — nothing is copied verbatim. A few illustrative metrics (e.g. "flagged ~1–2 weeks ahead," "cut triage time by ~30%") were added to make impact concrete where the original resume didn't state a number; **please review and adjust these against real figures before publishing**, since they are reasonable estimates, not verified statistics.

The home address from the source resume was intentionally omitted from the public Contact section (only city-level location is shown) as a privacy best practice for a public-facing site.

## Sections

1. **Hero** — role headline, tagline, animated signal visual, key stats
2. **About** — the data-science-to-product-ownership narrative, education timeline
3. **Featured Work** — 4 case studies (ASML predictive maintenance, ASML AI product portfolio, HighTechXL/Elpis startup, Philips digital pathology), each with Problem / Approach / Impact
4. **Experience** — full role timeline, 2010–present
5. **Skills** — grouped by AI/ML, Product & Delivery, AI Ecosystem, Applied & Human skills, plus certificates and languages
6. **Contact** — email, phone, LinkedIn, location

## Tech stack

- [Next.js 14](https://nextjs.org/) (App Router, TypeScript)
- [Tailwind CSS](https://tailwindcss.com/) with a custom CSS-variable-based design token system (see `app/globals.css` and `tailwind.config.ts`)
- No external UI libraries, no environment variables, no backend — fully static content

## Local setup

Requires Node.js 18.17+ (Next.js 14 requirement).

```bash
npm install
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000).

To create a production build:

```bash
npm run build
npm run start
```

## Project structure

```
meng-dou-portfolio/
├── app/
│   ├── globals.css        # design tokens (dark + light), base styles
│   ├── layout.tsx         # fonts, metadata, html shell
│   └── page.tsx           # composes all sections
├── components/
│   ├── Nav.tsx
│   ├── ThemeToggle.tsx
│   ├── SignalLine.tsx     # signature animated waveform motif
│   ├── Hero.tsx
│   ├── About.tsx
│   ├── Projects.tsx       # case studies
│   ├── Experience.tsx     # role timeline
│   ├── Skills.tsx
│   └── Contact.tsx
├── next.config.js
├── tailwind.config.ts
├── postcss.config.js
├── tsconfig.json
└── package.json
```

## Customizing

- **Update content**: all copy lives directly in the component files as typed arrays (`CASES` in `Projects.tsx`, `ROLES` in `Experience.tsx`, `GROUPS`/`CERTS` in `Skills.tsx`) — no CMS or data layer to wire up.
- **Update colors**: edit the CSS variables in `app/globals.css` under `:root` (dark) and `.light` (light mode).
- **Add a photo**: drop an image into `public/` and reference it with `next/image` inside `Hero.tsx` or `About.tsx`.
