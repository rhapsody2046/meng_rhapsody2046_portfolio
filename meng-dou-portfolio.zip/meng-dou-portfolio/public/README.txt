Add a profile photo or favicon here (e.g. headshot.jpg) and reference it with next/image in components/Hero.tsx or components/About.tsx.
