import SignalLine from './SignalLine';

const CHANNELS = [
  { label: 'Email', value: 'doumeng1988@gmail.com', href: 'mailto:doumeng1988@gmail.com' },
  { label: 'Phone', value: '+31 6 25 23 36 60', href: 'tel:+31625233660' },
  { label: 'LinkedIn', value: 'linkedin.com/in/doumengcarol', href: 'https://linkedin.com/in/doumengcarol' },
  { label: 'Based in', value: 'Eindhoven area, Netherlands', href: null },
];

export default function Contact() {
  return (
    <section id="contact" className="px-6 py-24">
      <div className="mx-auto max-w-content">
        <div className="rounded-3xl border border-border bg-surface px-8 py-14 text-center sm:px-16">
          <p className="eyebrow mb-4">Contact</p>
          <h2 className="mx-auto max-w-xl font-display text-2xl font-semibold text-ink sm:text-3xl">
            Open to Senior Data Scientist and AI Product Owner roles where models
            need to ship, not just publish.
          </h2>
          <SignalLine variant="divider" className="mx-auto my-8 h-6 w-40" />

          <div className="mx-auto grid max-w-2xl gap-6 sm:grid-cols-2">
            {CHANNELS.map((c) =>
              c.href ? (
                <a
                  key={c.label}
                  href={c.href}
                  target={c.href.startsWith('http') ? '_blank' : undefined}
                  rel={c.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="focus-ring card-hover rounded-xl border border-border bg-bg-elevated px-5 py-4 text-left"
                >
                  <p className="font-mono text-[11px] uppercase tracking-wide text-ink-faint">
                    {c.label}
                  </p>
                  <p className="mt-1 text-[14px] text-ink">{c.value}</p>
                </a>
              ) : (
                <div
                  key={c.label}
                  className="rounded-xl border border-border bg-bg-elevated px-5 py-4 text-left"
                >
                  <p className="font-mono text-[11px] uppercase tracking-wide text-ink-faint">
                    {c.label}
                  </p>
                  <p className="mt-1 text-[14px] text-ink">{c.value}</p>
                </div>
              )
            )}
          </div>
        </div>

        <p className="mt-10 text-center font-mono text-[12px] text-ink-faint">
          © {new Date().getFullYear()} Meng Dou. Built with Next.js &amp; Tailwind CSS.
        </p>
      </div>
    </section>
  );
}
