import SignalLine from './SignalLine';

const STATS = [
  { value: '13+', label: 'years in data science & AI product delivery' },
  { value: '6', label: 'AI initiatives owned end-to-end at ASML' },
  { value: '3', label: 'industries: semiconductors, health tech, cloud infra' },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden px-6 pt-20 pb-16 md:pt-28">
      <div className="mx-auto max-w-content">
        <div className="grid items-center gap-12 md:grid-cols-[1.1fr_0.9fr]">
          <div className="animate-fade-up">
            <p className="eyebrow mb-5 flex items-center gap-2">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-signal-teal animate-pulse-dot" />
              Senior Data Scientist &amp; AI Product Owner — ASML
            </p>
            <h1 className="font-display text-4xl font-semibold leading-[1.08] tracking-tight text-ink sm:text-5xl lg:text-[3.4rem]">
              I turn failure-prediction models into products that keep the world's most
              precise machines running.
            </h1>
            <p className="mt-6 max-w-xl text-[1.05rem] leading-relaxed text-ink-muted">
              Thirteen years at the intersection of machine learning and product leadership —
              building the models that catch equipment failure before it happens, and the
              cross-sector teams that ship them. Currently leading AI product delivery at ASML,
              from KPI health monitoring to Agile-led GenAI initiatives.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#work"
                className="focus-ring rounded-full bg-signal-teal px-6 py-3 font-mono text-[13px] font-medium text-bg transition-transform hover:-translate-y-0.5"
              >
                View case studies
              </a>
              <a
                href="#contact"
                className="focus-ring rounded-full border border-border px-6 py-3 font-mono text-[13px] text-ink transition-colors hover:border-signal-teal hover:text-signal-teal"
              >
                Get in touch
              </a>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl border border-border bg-surface p-6">
              <div className="mb-4 flex items-center justify-between">
                <span className="eyebrow">Equipment health signal — illustrative</span>
                <span className="font-mono text-[11px] text-ink-faint">live model output</span>
              </div>
              <SignalLine variant="hero" className="w-full" />
            </div>
          </div>
        </div>

        <dl className="mt-16 grid grid-cols-1 gap-8 border-t border-border pt-10 sm:grid-cols-3">
          {STATS.map((stat) => (
            <div key={stat.label}>
              <dt className="font-display text-3xl font-semibold text-ink">{stat.value}</dt>
              <dd className="mt-1 font-mono text-[12.5px] leading-snug text-ink-muted">
                {stat.label}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
