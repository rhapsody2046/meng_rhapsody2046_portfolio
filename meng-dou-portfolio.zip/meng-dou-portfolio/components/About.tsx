import SignalLine from './SignalLine';

const EDUCATION = [
  {
    period: '2010 — 2013',
    title: 'M.Sc. Computer Science',
    org: 'Tsinghua University, Beijing',
  },
  {
    period: '2012 — 2013',
    title: 'Visiting Researcher, Process Mining',
    org: 'Eindhoven University of Technology',
  },
  {
    period: '2011',
    title: 'HCI Summer Program — 1st place, product design competition',
    org: 'Stanford University',
  },
  {
    period: '2006 — 2010',
    title: 'B.Sc. Computer Science',
    org: 'Xiamen University',
  },
];

export default function About() {
  return (
    <section id="about" className="px-6 py-20">
      <div className="mx-auto max-w-content">
        <div className="grid gap-12 md:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow mb-4">About</p>
            <h2 className="font-display text-2xl font-semibold text-ink sm:text-3xl">
              Two disciplines, one delivery loop.
            </h2>
            <SignalLine variant="divider" className="my-6 h-6 w-40" />
            <p className="text-[1.02rem] leading-relaxed text-ink-muted">
              I started as a process-mining researcher, went deep into machine learning
              for industrial and clinical data, then moved into product ownership because
              the hardest part of AI was never the model — it was getting it adopted.
              At ASML I sit between data scientists, ML/software engineers, and
              cross-sector stakeholders, holding both the technical bar and the delivery
              roadmap for AI initiatives that touch equipment uptime across the fleet.
            </p>
            <p className="mt-4 text-[1.02rem] leading-relaxed text-ink-muted">
              I'm energized by translating a vague business problem into a scoped
              technical work package, then staying close enough to the model to know
              when its output is actually trustworthy. Outside of delivery, I mentor
              junior data scientists, pitch at innovation programs, and occasionally
              co-found things.
            </p>
          </div>

          <div>
            <p className="eyebrow mb-4">Education &amp; formation</p>
            <ul className="space-y-0">
              {EDUCATION.map((item, i) => (
                <li
                  key={item.title}
                  className={`flex gap-6 py-4 ${i !== EDUCATION.length - 1 ? 'border-b border-border' : ''}`}
                >
                  <span className="w-24 shrink-0 font-mono text-[12px] text-ink-faint">
                    {item.period}
                  </span>
                  <div>
                    <p className="font-medium text-ink">{item.title}</p>
                    <p className="mt-0.5 text-[13.5px] text-ink-muted">{item.org}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
