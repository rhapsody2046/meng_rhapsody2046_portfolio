'use client';

type SignalLineProps = {
  variant?: 'hero' | 'divider';
  className?: string;
};

export default function SignalLine({ variant = 'divider', className = '' }: SignalLineProps) {
  if (variant === 'hero') {
    return (
      <svg
        viewBox="0 0 900 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        role="img"
        aria-label="Illustrative equipment health signal with a predicted anomaly flagged before failure"
      >
        <line x1="0" y1="110" x2="900" y2="110" stroke="var(--border)" strokeWidth="1" strokeDasharray="2 6" />
        <path
          d="M0,120 C40,118 70,60 110,60 C150,60 160,150 200,150 C240,150 260,90 300,90 C330,90 345,105 365,108 C400,113 420,20 460,20 C490,20 505,140 540,150 C580,161 610,70 650,70 C690,70 705,130 745,130 C780,130 800,95 840,95 C860,95 875,100 900,100"
          stroke="var(--accent-teal)"
          strokeWidth="2.5"
          strokeLinecap="round"
          pathLength={1000}
          style={{ strokeDasharray: 1000, strokeDashoffset: 1000 }}
          className="animate-drawline"
        />
        <circle cx="460" cy="20" r="5" fill="var(--accent-amber)" />
        <circle cx="460" cy="20" r="10" fill="none" stroke="var(--accent-amber)" strokeWidth="1.5" className="animate-pulse-dot" />
        <text x="472" y="14" fontFamily="var(--font-mono)" fontSize="11" fill="var(--accent-amber)">
          anomaly flagged, 12d early
        </text>
        <circle cx="900" cy="100" r="4" fill="var(--accent-teal)" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 400 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M0,25 C15,25 20,15 30,15 C40,15 42,30 52,30 C62,30 68,10 80,10 C92,10 96,25 108,25 C120,25 126,18 140,18"
        stroke="var(--accent-teal)"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.55"
      />
    </svg>
  );
}
