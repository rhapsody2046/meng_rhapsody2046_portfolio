'use client';

import ThemeToggle from './ThemeToggle';

const LINKS = [
  { href: '#work', label: 'Work' },
  { href: '#experience', label: 'Experience' },
  { href: '#skills', label: 'Skills' },
  { href: '#contact', label: 'Contact' },
];

export default function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-bg/85 backdrop-blur">
      <nav className="mx-auto flex max-w-content items-center justify-between px-6 py-4">
        <a href="#top" className="focus-ring font-display text-sm font-semibold tracking-tight text-ink">
          Meng Dou
          <span className="ml-2 hidden font-mono text-[11px] font-normal text-signal-teal sm:inline">
            // DS + AI PRODUCT
          </span>
        </a>
        <div className="flex items-center gap-6">
          <ul className="hidden items-center gap-6 md:flex">
            {LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="focus-ring font-mono text-[13px] text-ink-muted transition-colors hover:text-signal-teal"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="focus-ring hidden rounded-full border border-signal-teal/50 px-4 py-1.5 font-mono text-[12px] text-signal-teal transition-colors hover:bg-signal-teal hover:text-bg sm:inline-block"
          >
            Let's talk
          </a>
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
