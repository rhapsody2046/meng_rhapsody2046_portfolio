const CASES = [
  {
    status: 'LIVE IN PRODUCTION',
    statusColor: 'teal',
    role: 'Data Scientist',
    title: 'Predictive failure detection & KPI health monitoring',
    org: 'ASML',
    problem:
      'Unscheduled downtime on high-value lithography systems was discovered reactively — after a KPI had already crossed a failure threshold, not before.',
    approach:
      'Built and deployed clustering-based failure-mode detection models alongside time-series KPI health monitors, surfacing degradation signals early enough for engineers to intervene before an unscheduled stop.',
    impact: [
      'Flagged degrading equipment KPIs roughly 1–2 weeks ahead of threshold breach',
      'Cut manual failure-mode triage time for the monitored fleet by an estimated 30%',
      'Model output filed as a granted patent (Failure Mode Detection based on clustering, 2022PF00198)',
    ],
    tags: ['Machine Learning', 'Predictive Maintenance', 'Time-series', 'Cloud Deployment'],
  },
  {
    status: 'SHIPPED · 6 INITIATIVES',
    statusColor: 'teal',
    role: 'AI Product Owner & Scrum Master',
    title: 'Owning a portfolio of AI products across sectors',
    org: 'ASML',
    problem:
      'AI initiatives spanning SPD, AI4DDF, DfS200, TPMS predictive use cases, and Equipment Edge each needed a single accountable owner to turn scattered business needs into a shippable backlog.',
    approach:
      'Held the product vision, 6-quarter roadmap, and backlog across a multidisciplinary Agile team — data scientists, ML/data engineers, IT/software/cloud engineers, and frontend — while aligning group leads, project leads, systems engineers, and architects on scope and value.',
    impact: [
      'Co-owned end-to-end delivery of 6 AI initiatives across distinct business sectors',
      'Kept cross-functional teams of 6–10 aligned through iterative, dynamic-scope delivery',
      'Became the go-to translator between business stakeholders and technical work packages',
    ],
    tags: ['Product Ownership', 'Agile / Scrum', 'Stakeholder Alignment', 'Roadmapping'],
  },
  {
    status: 'VALIDATED · GTM IN PROGRESS',
    statusColor: 'amber',
    role: 'Startup Co-founder, Product',
    title: 'Neutron-based non-destructive cargo detection',
    org: 'HighTechXL × Elpis',
    problem:
      'Cargo security screening relies on inspection methods that are slow, destructive, or both — with a real market gap for faster non-destructive detection.',
    approach:
      'As product-focused co-founder in ASML\u2019s startup program, partnered with deep-tech spinout Elpis to shape a neutron-energy detection device for the cargo inspection market, running customer discovery and building the investor narrative from scratch.',
    impact: [
      'Built and pitched the market validation case for a 0-to-1 hardware product',
      'Defined the initial go-to-market narrative for the cargo-detection use case',
      'Delivered the pitch that carried the venture through the program milestone review',
    ],
    tags: ['0-to-1 Product', 'Market Validation', 'Pitching', 'Deep Tech'],
  },
  {
    status: 'RESEARCH → IP FILED',
    statusColor: 'amber',
    role: 'Data Scientist',
    title: 'AI for digital pathology diagnostics',
    org: 'Philips',
    problem:
      'Pathologists were spending disproportionate time manually reading whole-slide images to detect cancer tissue and assess signaling-pathway activity.',
    approach:
      'Developed and deployed machine learning models for cancer tissue detection, and co-built a whole-slide-image workflow aimed at shortening pathologist review time, while contributing directly to IP generation.',
    impact: [
      'Research findings published on WSI-based workflows shortening pathologist reading time',
      '2 patents filed on mathematical modeling of signaling-pathway activity from gene expression',
      'Also shipped consumer-facing ML analysis for Philips Hue product insights',
    ],
    tags: ['Computer Vision', 'Healthcare AI', 'IP Generation', 'Research'],
  },
];

const statusStyles: Record<string, string> = {
  teal: 'border-signal-teal/40 text-signal-teal',
  amber: 'border-signal-amber/50 text-signal-amber',
};

export default function Projects() {
  return (
    <section id="work" className="px-6 py-20">
      <div className="mx-auto max-w-content">
        <div className="mb-12 flex flex-col gap-3">
          <p className="eyebrow">Featured work</p>
          <h2 className="font-display text-2xl font-semibold text-ink sm:text-3xl">
            Case studies, not a task list.
          </h2>
          <p className="max-w-2xl text-[1.02rem] leading-relaxed text-ink-muted">
            Four projects that show the same pattern from different angles: a real
            operational problem, a model or product decision that moved it, and a
            result someone downstream could act on.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {CASES.map((c) => (
            <article
              key={c.title}
              className="card-hover flex flex-col rounded-2xl border border-border bg-surface p-7"
            >
              <div className="mb-4 flex items-center justify-between gap-3">
                <span
                  className={`rounded-full border px-3 py-1 font-mono text-[10.5px] tracking-wide ${statusStyles[c.statusColor]}`}
                >
                  {c.status}
                </span>
                <span className="font-mono text-[11px] text-ink-faint">{c.org}</span>
              </div>

              <p className="mb-1 font-mono text-[12px] text-ink-faint">{c.role}</p>
              <h3 className="font-display text-xl font-semibold text-ink">{c.title}</h3>

              <div className="mt-4 space-y-3 text-[14px] leading-relaxed text-ink-muted">
                <p>
                  <span className="font-medium text-ink">Problem — </span>
                  {c.problem}
                </p>
                <p>
                  <span className="font-medium text-ink">Approach — </span>
                  {c.approach}
                </p>
              </div>

              <ul className="mt-4 space-y-1.5 border-t border-border pt-4">
                {c.impact.map((line) => (
                  <li key={line} className="flex gap-2 text-[13.5px] text-ink-muted">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-signal-teal" />
                    {line}
                  </li>
                ))}
              </ul>

              <div className="mt-5 flex flex-wrap gap-2">
                {c.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-border px-2.5 py-1 font-mono text-[10.5px] text-ink-muted"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
