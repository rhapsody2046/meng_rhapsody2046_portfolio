import Nav from '@/components/Nav';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Projects from '@/components/Projects';
import Experience from '@/components/Experience';
import Skills from '@/components/Skills';
import Contact from '@/components/Contact';

export default function Home() {
  return (
    <main className="min-h-screen bg-bg text-ink">
      <Nav />
      <Hero />
      <div className="mx-auto max-w-content px-6">
        <div className="section-divider" />
      </div>
      <About />
      <div className="mx-auto max-w-content px-6">
        <div className="section-divider" />
      </div>
      <Projects />
      <div className="mx-auto max-w-content px-6">
        <div className="section-divider" />
      </div>
      <Experience />
      <div className="mx-auto max-w-content px-6">
        <div className="section-divider" />
      </div>
      <Skills />
      <Contact />
    </main>
  );
}
